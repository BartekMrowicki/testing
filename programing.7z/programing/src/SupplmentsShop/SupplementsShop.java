package SupplmentsShop;

import java.util.ArrayList;

import java.io.FileReader;

import java.io.FileWriter;

import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;



import com.thoughtworks.xstream.XStream;

import com.thoughtworks.xstream.io.xml.DomDriver;

public class SupplementsShop {

	private ArrayList<Product> stock;

	private static int stockId=0;

	

	

	public SupplementsShop()

	{

		stock = new ArrayList<Product>();

	}

	

	public void addProduct(String name, String description,String Brand, double weight,

			double cost, String cat, String subCat)

    { 

      Product product = new Product(name,description,Brand,weight,cost, cat, subCat);

      stock.add(product);

    }

	

	/**

     * listAllProducts() - This method returns the index number and the title of each 

     * element in the Products ArrayList.

     */

     public String listProducts()

     {

       int i=0;

       String displayProducts = "All Products";

       for (Product item:stock){

    	   displayProducts += "\n"+ (i++) + ": " + item;

       }

       return displayProducts;

     }

     

     /**

      * listCatProducts() - This method returns the index number and the title of each 

      * element in the Products ArrayList whose category field matches the parameter supplied.

      */

      public String listCategoryProducts(String cat)

      {

        int i=0;

        String displayProducts = "All Products";

        for (Product item:stock){

        	if (item.getCategory().equals(cat)){

        		displayProducts += "\n"+ (i++) + ": " + item;

        	}

        }

        return displayProducts;

      }

      

      /**

       * listCatProducts() - This method returns the index number and the title of each 

       * element in the Products ArrayList whose category field matches the parameter supplied.

       */

       public String listCategoryAndSubCategoryProducts(String cat, String subCat)

       {

         String displayProducts;

         displayProducts=""+cat+"----"+subCat;

         for (Product item:stock){

         	if (item.getCategory().equals(cat) && item.getSubCategory().equals(subCat)){

         		displayProducts+= "\n"+ item.getId() + ": " + item.getName();

         	}

         	else if (cat.equals("All")){

         		displayProducts+= "\n"+ item.getId() + ": " + item.getName();

         	}

         }

         return displayProducts;

       }

       

       /** get Product details

        * 

        */

       public Product getProdDetails(String id){

    	 int id1 = (Integer.parseInt(id));  //Test only

    	   

    	   for (Product item:stock){

            	if (item.getId()==id1){

            		return item;

            	}

    	   }

    	   return null;

       }

	

	 /**

     * save() - This method saves the contents of the stock ArrayList and bargains ArrayList to 

     * an XML file called products.xml

     * */

     public void saveProducts() throws Exception

     {

     XStream xstream = new XStream(new DomDriver());

     ObjectOutputStream out = xstream.createObjectOutputStream

     (new FileWriter("Product.xml"));

     out.writeObject(stock);

     out.close();

     }



     /**

     * load() - This method reads the contents of the XML file called 

     * products.xml stored in the project directory.  The file should contain two components -

     *    an ArrayList of Product, and

     *    an ArrayList of BargainBundle.

     * The contents are casted as an ArrayList of Product and stored in the stock variable. 

     * The remaining contents are casted as an ArrayList of BargainBundle and stored in the bargains variable.

     * */

     public void loadProducts() throws Exception

     {

     XStream xstream = new XStream(new DomDriver());

     ObjectInputStream is = xstream.createObjectInputStream

     (new FileReader("Product.xml"));

     stock = (ArrayList<Product>) is.readObject();

     is.close();

     }

	public String getTitle()

	{

		return("European Supplments Shop");

	}

}

