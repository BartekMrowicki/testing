package SupplmentsShop;

import java.io.IOException;
import java.net.URL;

import java.util.ResourceBundle;

import java.util.ArrayList;

import javafx.collections.FXCollections;

import javafx.collections.ObservableList;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import javafx.scene.control.TextArea;

import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Scene;


public class RegistrationController {

@FXML

private TextField FirstName;

@FXML
private TextField Surname;
@FXML
private TextField Email;
@FXML
private TextField PersonalUsername;
@FXML
private TextField Country;
@FXML
private TextArea Town;
@FXML
private TextArea Password;
@FXML
private TextArea ConfirmPassword;


Stage dialogStage = new Stage();
Scene scene;


private ArrayList<Users> User = new ArrayList<Users>();

private static int UserId=0;


public void addUser(String name, String sur,String email, String PersonalUsername, String Country,String town,String pass,String cpass)

{ 

  RegistrationController user = new RegistrationController(name,sur,email,PersonalUsername,Country,town,pass,cpass);

  user.add(user);

}



private void add(RegistrationController user2) {
	// TODO Auto-generated method stub
	
}



public void handleAddBtn(ActionEvent e) throws Exception{

String name = FirstName.getText();

String sur = Surname.getText();

String email = Email.getText();

String user = PersonalUsername.getText();

String country = Country.getText();

String town = Town.getText();

String pass = Password.getText();

String cpass = ConfirmPassword.getText();





user.addUser(name, sur, email, user, country, town, pass, cpass); 


}

public void handleSaveBtn(ActionEvent e) throws Exception{
	addUser.saveusers();
	

	
}








@FXML
public void handleBackBtn(ActionEvent e){

            Node node = (Node)e.getSource();

            dialogStage = (Stage) node.getScene().getWindow();

            dialogStage.close();

            try {

scene = new Scene(FXMLLoader.load(getClass().getResource("Login.fxml")));

} catch (IOException e1) {



e1.printStackTrace();

}

            dialogStage.setScene(scene);

            dialogStage.show();

}










}