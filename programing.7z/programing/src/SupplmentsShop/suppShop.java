import java.util.ArrayList;

import java.io.FileReader;

import java.io.FileWriter;

import java.io.ObjectInputStream;

import java.io.ObjectOutputStream;



import com.thoughtworks.xstream.XStream;

import com.thoughtworks.xstream.io.xml.DomDriver;

public class suppShop {

    private ArrayList<Product> stock;

   // private ArrayList<BargainBundle> bargains;

    

    public suppShop()

    {

    	stock = new ArrayList<Product>();

    //	bargains=new ArrayList<BargainBundle>();

    }

    

    public static void  main(String[] args)

    { 

    	suppShop app = new suppShop();

    	app.run();

    } 

    

    public void  run()

    {

    	int choice;

    	do{

    		choice = mainMenu();

    		switch(choice){

    		case 1: addProduct();

    				break;

    		case 2: listProducts();

			break;

    		case 3: editProduct();

			break;

    		case 4: deleteProduct();

			break;

  		case 10: try {

    			loadProducts();

    		}

			catch(Exception e){

				System.out.println("Error reading from file: " + e);

			}

    		break;

    		case 11: try{

    			saveProducts();

    		}

			catch(Exception e){

				System.out.println("Error writing to file: " + e);

			}

    		}

    	}while (choice !=0);

    	System.out.println("Thank you for using our shop");

    }

	

    private int mainMenu()

    {

      

      System.out.println("1) Add a Product");

      System.out.println("2) List all Products");       

      System.out.println("3) Edit a Product");

      System.out.println("4) Delete a Product");

      System.out.println("--------------");

     System.out.println("10) Load all Products");

      System.out.println("11) Save all Products");

      System.out.println("0) Exit");

      System.out.print("==>>");

      int option = EasyScanner.nextInt();

      return option;

    }

    

    /**

     * addProduct() - This method asks the user to enter a title of a Product.  

     * This title is  read from the console and added to the Products ArrayList. 

     */

     public void addProduct()

     {

       System.out.print("Product id: ");

       String productId = EasyScanner.nextString();

       System.out.print("Product Name: ");

       String productName = EasyScanner.nextString();

       System.out.print("Product Description: ");

       String productDesc = EasyScanner.nextString();

       System.out.print("Product weight(Grams): ");

       double productWeight = EasyScanner.nextDouble();

       System.out.print("Product cost: ");

       double productCost = EasyScanner.nextDouble();

       Product product = new Product(productId,productName,productDesc,productWeight,productCost);

       stock.add(product);

     }

  

     /**

     * listProducts() - This method prints the index number and the title of each 

     * element in the Products ArrayList to the console.

     */

     public void listProducts()

     {

       int i=0;

       for (Product item:stock){

    	   System.out.println(i++ + ": " + item);

       }

     }

  

     /**

     * editProduct() - This method lists all the stored Products, asks the user to select 

     * one to edit and enter a new title, and change the title of the selected

     * Product in the ArrayList. 

     */

     public void editProduct()

     {

       listProducts();

       System.out.print("Product to edit ==>");

       int index = EasyScanner.nextInt();

       Product item = stock.get(index);

       System.out.println(index + ": " + item);

       String itemId= item.getItemId();

       System.out.println("Enter the new values for product "+itemId+" >");

       

       System.out.print("Product Name: ");

       String productName = EasyScanner.nextString();

       System.out.print("Product Description: ");

       String productDesc = EasyScanner.nextString();

       System.out.print("Product weight(Grams): ");

       double productWeight = EasyScanner.nextDouble();

       System.out.print("Product cost: ");

       double productCost = EasyScanner.nextDouble();

       Product product = new Product(itemId,productName,productDesc,productWeight,productCost);

       stock.add(product);

     }



     /**

     * deleteProduct() - This method lists all the stored Products, asks the user to 

     * select one to delete and removes it from the ArrayList. 

     */

     public void deleteProduct()

     {

       listProducts();

       System.out.print("Product to delete ==>");

       int index = EasyScanner.nextInt();

       Product item = stock.get(index);

       System.out.println(index + ": " + item);

       int itemId= item.getItemId();

       System.out.println("Removing Product "+itemId+" >");

       stock.remove(index);

     }

       

     /**

     * save() - This method saves the contents of the stock ArrayList to 

     * an XML file called myProducts.xml

     * */

     public void saveProducts() throws Exception

     {

     XStream xstream = new XStream(new DomDriver());

     ObjectOutputStream out = xstream.createObjectOutputStream

     (new FileWriter("products.xml"));

     out.writeObject(stock);

     out.close();

     }



     /**

     * load() - This method reads the contents of the XML file called 

     * myProducts.xml stored in the project directory.  The contents are 

     * casted as an ArrayList of Strings and stored in the Products variable.  

     * */

     public void loadProducts() throws Exception

     {

     XStream xstream = new XStream(new DomDriver());

     ObjectInputStream is = xstream.createObjectInputStream

     (new FileReader("products.xml"));

     stock = (ArrayList<Product>) is.readObject();

     is.close();

     }

}