package SupplmentsShop;

import java.io.IOException;
import java.net.URL;

import java.util.ResourceBundle;



import javafx.collections.FXCollections;

import javafx.collections.ObservableList;

import javafx.event.ActionEvent;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;

import javafx.scene.control.TextArea;

import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;

public class MainMenuController implements Initializable {

protected SupplementsShop shop;

String category, subCategory;

@FXML

private TextField txtId;


@FXML
private TextField txtName;
@FXML
private TextField txtPrice;
@FXML
private TextField txtBrand;
@FXML
private TextField txtWeight;
@FXML
private TextArea txtFeedback;
@FXML
private TextArea txtProductdescription;


Stage dialogStage = new Stage();
Scene scene;




public void handleReadBtn(ActionEvent e){

txtFeedback.setText("Reading Product ");

String id = txtId.getText();



Product productDetails = shop.getProdDetails(id);

if(productDetails==null) // checking for null return otherwise you will get a null pointer error

txtFeedback.setText("Invalid Product- Not Read");

else{  //setting the TextFields
	txtProductdescription.appendText ("\n" + "Product ID:" + productDetails.getId());

	txtProductdescription.appendText ("\n" + "Product Name:" +productDetails.getName());
	
	txtProductdescription.appendText ("\n" + "Product Brand:" +productDetails.getBrand());

	txtProductdescription.appendText ("\n" + "Product Weight:" +productDetails.getWeight());

	txtProductdescription.appendText ("\n" +"Product Price:" + productDetails.getPrice());


txtFeedback.setText("Product Read");

}

}

public void handleAddBtn(ActionEvent e) throws Exception{

String name = txtName.getText();

String desc = txtProductdescription.getText();

String Brand = txtBrand.getText();



double weight = Double.valueOf(txtWeight.getText()); //Using the Wrapper class to convert String to double

double cost = Double.valueOf(txtPrice.getText());



shop.addProduct(name, desc, Brand, weight, cost, "Male", "Sport"); //Notice category and SubCategory are static

txtFeedback.setText("Product Added");

}

public void handleSaveBtn(ActionEvent e) throws Exception{
	shop.saveProducts();
	txtFeedback.setText("Product Saved");

	
}

public void handleLoadBtn(ActionEvent e) throws Exception{
	shop.loadProducts();
	txtFeedback.setText("Product Loaded");
}



@Override

public void initialize(URL location, ResourceBundle resources) {

shop= new SupplementsShop();

category="All";

subCategory="All";
/*
comboCategory.setItems(categories);

comboSubCategory.setItems(subCategories);

comboCategory.setValue("All");

comboSubCategory.setValue("All");
*/
}

@FXML
public void handleBackBtn(ActionEvent e){

            Node node = (Node)e.getSource();

            dialogStage = (Stage) node.getScene().getWindow();

            dialogStage.close();

            try {

scene = new Scene(FXMLLoader.load(getClass().getResource("MainMenu.fxml")));

} catch (IOException e1) {



e1.printStackTrace();

}

            dialogStage.setScene(scene);

            dialogStage.show();

}










}


