package SupplmentsShop;
public class Product {

	private static int productId=0;

	

	private int id;

	private String name;

	private String description;
	
	private String Brand;

	private double weight;

	private double Price;

	private boolean inStock;

	private String category;

	private String subCategory;

	

	public Product( String name, String description, String Brand,  double weight,

			double Price, String cat, String subCat) {

		super();

		this.id = productId++;

		this.name = name;

		this.description = description;
		
		this.Brand = Brand;

		this.weight = weight;

		this.Price = Price;

		this.inStock = true;

		category =cat;

		subCategory =subCat;

	}

	

	public int getId() {

		return id;

	}



	public void setId(int id) {

		this.id = id;

	}



	public String getCategory() {

		return category;

	}



	public void setCategory(String category) {

		this.category = category;

	}



	public String getSubCategory() {

		return subCategory;

	}



	public void setSubCategory(String subCategory) {

		this.subCategory = subCategory;

	}



	public String toString() {

		return "Product [id=" + id + ", name=" + name + ", description="

				+ description +", Brand=" + Brand + ", weight=" + weight + ", Price=" + Price

				+ ", inStock=" + inStock + "]";

	}





	public String getName() {

		return name;

	}

	
	public void setName(String name) {

		this.name = name;

	}



	public String getDescription() {

		return description;

	}



	public void setDescription(String description) {

		this.description = description;

	}



	public double getWeight() {

		return weight;

	}



	public void setWeight(double weight) {

		this.weight = weight;

	}



	public double getPrice() {

		return Price;

	}



	public void setPrice(double Price) {

		this.Price = Price;

	}



	public boolean isInStock() {

		return inStock;

	}



	public void setInStock(boolean inStock) {

		this.inStock = inStock;

	}


	public void setBrand(String Brand) {

		this.Brand = Brand;

	}
	public String getBrand() {

		return Brand;

	}

	




	
	

}